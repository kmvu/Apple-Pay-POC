# Apple-Pay-POC
A POC project to demonstrate Apple Pay using Swift 4 for iOS
